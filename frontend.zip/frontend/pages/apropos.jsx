import React from "react";
import Apropos from "../components/Apropos";

export default function apropos() {
    return ( <div> <Apropos /> </div>)
} 
