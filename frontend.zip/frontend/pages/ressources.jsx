import React from 'react';
import Ressources from '../components/Ressources';

export default function RessourcesPage() {
  return  ( <div> <Ressources /> </div>)
}


