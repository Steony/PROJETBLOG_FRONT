import Home from '../components/Home';

function Index() {
  return <Home />;
}

export default Index;
